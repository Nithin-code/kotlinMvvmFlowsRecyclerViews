package com.nithin.kotlinmvvm.callbacks

interface AlbumCallbacks {

    fun onItemClick(position : Int)

}
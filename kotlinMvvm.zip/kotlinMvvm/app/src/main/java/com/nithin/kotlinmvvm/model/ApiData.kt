package com.nithin.kotlinmvvm.model


data class ApiData(
    val albumsList : List<AlbumData>
)
